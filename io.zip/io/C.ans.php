#!/usr/bin/php
<?
/*
Check program for Problem C
*/

$input = file_get_contents('C.in');
$output = file_get_contents('output', FALSE, NULL, 0, 128 * 1024);

$input = trim(preg_replace('%\s+%', ' ', $input));
$output = trim(preg_replace('%\s+%', ' ', $output));
$input = explode(' ', $input);
$output = explode(' ', $output);
$ip = $op = 0;

$dataset = 0;
while (($n = (int)$input[$ip++]) != 0) {
	$x = $y = array(); $dataset++;
	for ($i = 0; $i < $n; $i++) {
		$x[] = (double)$input[$ip++];
		$y[] = (double)$input[$ip++];
	}
	if (!isset($output[$op])) {
		exit(101);
	}
	$r = (double)$output[$op++];
	$r += atan2($y[0], $x[0]);
	$ax = cos($r); $ay = sin($r);
	$da = $db = 0;
	for ($i = 0; $i < $n; $i++) {
		if (abs($ax * $y[$i] - $x[$i] * $ay) < 1e-6) {
			echo "Wrong Answer\n";
			exit(101);
		}
		if ($ax * $y[$i] < $x[$i] * $ay) {
			$da++;
		} else {
			$db++;
		}
	}
	if ($da != $db) {
		echo "Wrong Answer\n";
		exit(101);
	}
}
exit(100);

?>